import Layout from "./Layout.jsx";

import About from "./About";

import AdminDashboard from "./AdminDashboard";

import AdminLogin from "./AdminLogin";

import AssessmentPage from "./AssessmentPage";

import CPD from "./CPD";

import ClassUnlocks from "./ClassUnlocks";

import Contact from "./Contact";

import ExploreGames from "./ExploreGames";

import Home from "./Home";

import MainAdminDashboard from "./MainAdminDashboard";

import StudentLogin from "./StudentLogin";

import StudentProgressDashboard from "./StudentProgressDashboard";

import TakeQuiz from "./TakeQuiz";

import ViewResources from "./ViewResources";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    About: About,
    
    AdminDashboard: AdminDashboard,
    
    AdminLogin: AdminLogin,
    
    AssessmentPage: AssessmentPage,
    
    CPD: CPD,
    
    ClassUnlocks: ClassUnlocks,
    
    Contact: Contact,
    
    ExploreGames: ExploreGames,
    
    Home: Home,
    
    MainAdminDashboard: MainAdminDashboard,
    
    StudentLogin: StudentLogin,
    
    StudentProgressDashboard: StudentProgressDashboard,
    
    TakeQuiz: TakeQuiz,
    
    ViewResources: ViewResources,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<About />} />
                
                
                <Route path="/About" element={<About />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AdminLogin" element={<AdminLogin />} />
                
                <Route path="/AssessmentPage" element={<AssessmentPage />} />
                
                <Route path="/CPD" element={<CPD />} />
                
                <Route path="/ClassUnlocks" element={<ClassUnlocks />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/ExploreGames" element={<ExploreGames />} />
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/MainAdminDashboard" element={<MainAdminDashboard />} />
                
                <Route path="/StudentLogin" element={<StudentLogin />} />
                
                <Route path="/StudentProgressDashboard" element={<StudentProgressDashboard />} />
                
                <Route path="/TakeQuiz" element={<TakeQuiz />} />
                
                <Route path="/ViewResources" element={<ViewResources />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}