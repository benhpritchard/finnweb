import { base44 } from './base44Client';


export const recordGameScore = base44.functions.recordGameScore;

export const sendBookingEmail = base44.functions.sendBookingEmail;

